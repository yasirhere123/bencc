<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\loginController;
use App\Http\Controllers\subscriberController;
use App\Http\Controllers\paymentController;
use App\Http\Controllers\inspectionController;
/*
|---------------------------------------------------------------------	-----
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });
Route::middleware('cors')->group(function(){
Route::any('/clear-cache', function() {
    Artisan::call('cache:clear');
    Artisan::call('config:clear');
    Artisan::call('view:clear');
    Artisan::call('route:clear');
    return "Cache is cleared";
});
Route::any('/memberpayment', [paymentController::class, 'memberpayment']);
Route::any('/responsepayment', [paymentController::class, 'responsepayment']);
Route::any('/inquirypayment', [paymentController::class, 'inquirypayment']);

Route::any('/ganerateinspection', [inspectionController::class, 'ganerateinspection']);
Route::any('/uploadinspectionimage', [inspectionController::class, 'uploadinspectionimage']);
Route::any('/saveinitialinspection', [inspectionController::class, 'saveinitialinspection']);
Route::any('/savebodyinspection', [inspectionController::class, 'savebodyinspection']);
Route::any('/saveacinspection', [inspectionController::class, 'saveacinspection']);
Route::any('/savetestdriveinspection', [inspectionController::class, 'savetestdriveinspection']);
Route::any('/savesuspensioninspection', [inspectionController::class, 'savesuspensioninspection']);
Route::any('/savetyreeeinspection', [inspectionController::class, 'savetyreeeinspection']);
Route::any('/inspectionreport', [inspectionController::class, 'inspectionreport']);
Route::any('/saveinteriorinspection', [inspectionController::class, 'saveinteriorinspection']);
Route::any('/saveexteriorinspection', [inspectionController::class, 'saveexteriorinspection']);
Route::any('/inspectionlist', [inspectionController::class, 'inspectionlist']);
Route::any('/getinspectionimage', [inspectionController::class, 'getinspectionimage']);

Route::any('/savesubscriber', [subscriberController::class, 'savesubscriber']);
Route::any('/login', [loginController::class, 'login']);
Route::group(['middleware' => ['jwt.verify']], function() {
Route::any('/logout', [loginController::class, 'logout']);
Route::any('/getUser', [loginController::class, 'getUser']);
});
});