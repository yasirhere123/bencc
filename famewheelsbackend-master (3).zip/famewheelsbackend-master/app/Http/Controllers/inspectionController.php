<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\File;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Http;
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use GuzzleHttp\Client;
use Image;
use DB;
use Input;
use Session;
use Response;
use Validator;
use URL;

class inspectionController extends Controller {
	public function ganerateinspection(Request $request){
		$iinitial_token = openssl_random_pseudo_bytes(7);
		$iinitial_token = bin2hex($iinitial_token);
		// $initial = DB::table('iinitial')
		// ->select('*')
		// ->where('status_id','=',1)
		// ->where('iinitial_token','=',$request->iinitial_token)
		// ->first();
		if($iinitial_token){
			return response()->json(['iinitial_token' => $iinitial_token,'message' => 'Inspection Generate Successfully'],200);
		}else{
			return response()->json("Oops! Something Went Wrong", 400);
		}
	}
	public function uploadinspectionimage(Request $request){
		$validate = Validator::make($request->all(), [ 
			'iinitial_token'		=> 'required',
			'image_name'			=> 'required',
			'image_file'			=> 'required',
			'inspectionstep_id'		=> 'required',
			'inspectionstep_name'		=> 'required',
		]);
		if ($validate->fails()) {    
			return response()->json($validate->errors(), 400);
		}
		if ($request->has('image_file')) {
			if( $request->image_file->isValid()){
				$number = rand(1,999);
				$numb = $number / 7 ;
				$name = "image_file";
				$extension = $request->image_file->extension();
				$image_name  = date('Y-m-d')."_".$numb."_".$name."_.".$extension;
				$image_name = $request->image_file->move(public_path($request->inspectionstep_name.'/'.$request->iinitial_token.'/'),$image_name);
				$img = Image::make($image_name)->resize(800,800, function($constraint) {
						$constraint->aspectRatio();
				});
				$img->save($image_name);
				$image_name = date('Y-m-d')."_".$numb."_".$name."_.".$extension;
				$adds = array(
					'inspectionimage_name' 			=> $image_name,
					'inspectionimage_placement' 	=> $request->image_name,
					'inspectionstep_id' 			=> $request->inspectionstep_id,
					'iinitial_token' 				=> $request->iinitial_token,
					'status_id'						=> 1,
				);
				DB::table('inspectionimage')->insert($adds);
				return response()->json(['message' => 'Uploaded Successfully'],200);
			}else{
				return response()->json("Invalid Format", 400);
			}
		}
		return response()->json("Oops! Something Went Wrong", 400);
	}
	public function getinspectionimage(Request $request){
		$validate = Validator::make($request->all(), [ 
			'iinitial_token'				=> 'required',
			'inspectionimage_placement'		=> 'required',
		]);
		if ($validate->fails()) {    
			return response()->json($validate->errors(), 400);
		}
		$data = DB::table('inspectiondetail')
		->select('inspectionimage_name','inspectionstep_name')
		->where('iinitial_token','=',$request->iinitial_token)
		->where('inspectionimage_placement','=',$request->inspectionimage_placement)
		->where('status_id','=',1)
		->first();
		if(isset($data->inspectionimage_name)){
			$imagepath = URL::to( '/' ).'/public'.'/'.$data->inspectionstep_name.'/'.$request->iinitial_token.'/'.$data->inspectionimage_name;
		}else{
			$imagepath = URL::to( '/' ).'/public/no_image.png';
		}
		return response()->json(['imagepath' => $imagepath],200);
	}
    public function saveinitialinspection(Request $request){
		$validate = Validator::make($request->all(), [ 
			'iinitial_token'			=> 'required',
			'iinitial_customername' 	=> 'required',
			'iinitial_customeremail' 	=> 'required',
			'iinitial_customerno' 		=> 'required',
			'iinitial_customernic' 		=> 'required',
			'iinitial_customeraddress' 	=> 'required',
			'iinitial_vehicletitle' 	=> 'required',
			'iinitial_ownername' 		=> 'required',
			'iinitial_mileage'			=> 'required',
			'iinitial_date' 			=> 'required',
			'iinitial_engineno'			=> 'required',
			'iinitial_transmission' 	=> 'required',
			'iinitial_location'			=> 'required',
			'iinitial_enginecapacity'	=> 'required',
			'iinitial_chasisno'			=> 'required',
			'iinitial_fueltype'			=> 'required',
			'iinitial_registeredno'		=> 'required',
			'iinitial_color'			=> 'required',
			'city_id'					=> 'required',
			'is_edit'					=> 'required',
		]);
		if ($validate->fails()) {    
			return response()->json($validate->errors(), 400);
		}
		$adds = array(
		'iinitial_customername' 	=> $request->iinitial_customername,
		'iinitial_customeremail' 	=> $request->iinitial_customeremail,
		'iinitial_customerno' 	=> $request->iinitial_customerno,
		'iinitial_customernic' 	=> $request->iinitial_customernic,
		'iinitial_customeraddress' 	=> $request->iinitial_customeraddress,
		'iinitial_vehicletitle' 	=> $request->iinitial_vehicletitle,
		'iinitial_ownername' 	=> $request->iinitial_ownername,
		'iinitial_mileage' 			=> $request->iinitial_mileage,
		'iinitial_date'				=> $request->iinitial_date,
		'iinitial_engineno' 		=> $request->iinitial_engineno,
		'iinitial_transmission' 	=> $request->iinitial_transmission,
		'iinitial_location' 		=> $request->iinitial_location,
		'iinitial_enginecapacity' 	=> $request->iinitial_enginecapacity,
		'iinitial_chasisno' 		=> $request->iinitial_chasisno,
		'iinitial_fueltype' 		=> $request->iinitial_fueltype,
		'iinitial_registeredno' 	=> $request->iinitial_registeredno,
		'iinitial_color' 			=> $request->iinitial_color,	
		'city_id' 					=> $request->city_id,
		'iinitial_token' 			=> $request->iinitial_token,
		'status_id'					=> 1,
		'created_by'				=> $request->userId,
		'created_at'				=> date('Y-m-d h:i:s'),
		);
		if($request->is_edit == 0){
			$save = DB::table('iinitial')->insert($adds);
			$iinitial_id  = DB::getPdo()->lastInsertId();
		}else{
			$save  = DB::table('iinitial')
			->where('iinitial_id','=',$request->iinitial_id)
			->update($adds);
			$iinitial_id  = $request->iinitial_id;
		}
		if($save){
			return response()->json(['iinitial_id' => $iinitial_id, 'iinitial_token' => $request->iinitial_token, 'message' => 'Initial Inspection Saved Successfully'],200);
		}else{
			return response()->json("Oops! Something Went Wrong", 400);
		}
	}
	public function savebodyinspection(Request $request){
		$validate = Validator::make($request->all(), [ 
		      'ibody_rediatorcore' 			=> 'required',
		      'ibody_leftstruttowerapron'			=> 'required',
		      'ibody_leftfrontrail' 			=> 'required',
		      'ibody_bootlockpillar'			=> 'required',
		      'ibody_frontsubframe' 		=> 'required',
		      'ibody_rightapillar'		=> 'required',
			  'ibody_rightbpillar'		=> 'required',
			  'ibody_rightcpillar'		=> 'required',
			  'ibody_rightdpillar'		=> 'required',
			  'ibody_rightstruttowerapron'		=> 'required',
			  'ibody_rightfrontrail'		=> 'required',
			  'ibody_bootfloor'		=> 'required',
			  'ibody_rearsubframe'		=> 'required',
			  'ibody_cowlpanelfirewall'		=> 'required',
			  'ibody_leftapillar'		=> 'required',
			  'ibody_leftbpillar'		=> 'required',
			  'ibody_leftcpillar'		=> 'required',
			  'ibody_leftdpillar'		=> 'required',
			  'ibody_frontrightdisc'		=> 'required',
			  'ibody_frontleftdisc'		=> 'required',
			  'ibody_frontrightbrakepad'		=> 'required',
			  'ibody_frontleftbrakepad'		=> 'required',
			  'iinitial_id'		=> 'required',
			  'iinitial_token'		=> 'required',
			  'is_edit'					=> 'required',
		    ]);
	     	if ($validate->fails()) {    
				return response()->json($validate->errors(), 400);
			}
			$adds = array(
			'ibody_rediatorcore' 	=> $request->ibody_rediatorcore,
			'ibody_leftstruttowerapron' 			=> $request->ibody_leftstruttowerapron,
			'ibody_leftfrontrail'				=> $request->ibody_leftfrontrail,
			'ibody_bootlockpillar' 		=> $request->ibody_bootlockpillar,
			'ibody_frontsubframe' 	=> $request->ibody_frontsubframe,
			'ibody_rightapillar' 					=> $request->ibody_rightapillar,
			'ibody_rightbpillar' 					=> $request->ibody_rightbpillar,
			'ibody_rightcpillar' 					=> $request->ibody_rightcpillar,
			'ibody_rightdpillar' 					=> $request->ibody_rightdpillar,
			'ibody_rightstruttowerapron' 					=> $request->ibody_rightstruttowerapron,
			'ibody_rightfrontrail' 					=> $request->ibody_rightfrontrail,
			'ibody_bootfloor' 					=> $request->ibody_bootfloor,
			'ibody_rearsubframe' 					=> $request->ibody_rearsubframe,
			'ibody_cowlpanelfirewall' 					=> $request->ibody_cowlpanelfirewall,
			'ibody_leftapillar' 					=> $request->ibody_leftapillar,
			'ibody_leftbpillar' 					=> $request->ibody_leftbpillar,
			'ibody_leftcpillar' 					=> $request->ibody_leftcpillar,
			'ibody_leftdpillar' 					=> $request->ibody_leftdpillar,
			'ibody_frontrightdisc' 					=> $request->ibody_frontrightdisc,
			'ibody_frontleftdisc' 					=> $request->ibody_frontleftdisc,
			'ibody_frontrightbrakepad' 					=> $request->ibody_frontrightbrakepad,
			'ibody_frontleftbrakepad' 					=> $request->ibody_frontleftbrakepad,
			'iinitial_id' 					=> $request->iinitial_id,
			'iinitial_token' 					=> $request->iinitial_token,
			'status_id'					=> 1,
			'created_by'				=> $request->userId,
			'created_at'				=> date('Y-m-d h:i:s'),
			);
			if($request->is_edit == 0){
				$save = DB::table('ibody')->insert($adds);
			}else{
				$save  = DB::table('ibody')
				->where('iinitial_id','=',$request->iinitial_id)
				->update($adds);
			}
		if($save){
			return response()->json(['message' => 'Body Inspection Saved Successfully'],200);
		}else{
			return response()->json("Oops! Something Went Wrong", 400);
		}
	}
	public function saveacinspection(Request $request){
		$validate = Validator::make($request->all(), [ 
		      'iac_acfitted' 			=> 'required',
		      'iac_acoperational'			=> 'required',
		      'iac_blower' 			=> 'required',
		      'iac_cooling'			=> 'required',
		      'iac_heating' 		=> 'required',
		      'iac_engineoillevel'		=> 'required',
		      'iac_engineoilleakage'	=> 'required',
			  'iac_transmissionoilleakage'	=> 'required',
			  'iac_coolantleakage'		=> 'required',
			  'iac_brakeoilleakage'		=> 'required',
			  'iac_fanbelts'		=> 'required',
			  'iac_wiringharmess'		=> 'required',
			  'iac_engineblow'		=> 'required',
			  'iac_enginenoise'		=> 'required',
			  'iac_enginevibration'		=> 'required',
			  'iac_enginemounts'		=> 'required',
			  'iac_pulleysadjuster'		=> 'required',
			  'iac_hoses'		=> 'required',
			  'iac_rediator'		=> 'required',
			  'iac_suctionfan'		=> 'required',
			  'iac_exhaustsound'		=> 'required',
			  'iac_starteroperation'		=> 'required',
			   'iinitial_id'		=> 'required',
			  'iinitial_token'		=> 'required',
			  'is_edit'					=> 'required',
		    ]);
	     	if ($validate->fails()) {    
				return response()->json($validate->errors(), 400);
			}
			$adds = array(
			'iac_acfitted' 	=> $request->iac_acfitted,
			'iac_acoperational' 			=> $request->iac_acoperational,
			'iac_blower'				=> $request->iac_blower,
			'iac_cooling' 		=> $request->iac_cooling,
			'iac_heating' 	=> $request->iac_heating,
			'iac_engineoillevel' 		=> $request->iac_engineoillevel,
			'iac_engineoilleakage' 	=> $request->iac_engineoilleakage,
			'iac_transmissionoilleakage' 	=> $request->iac_transmissionoilleakage,
			'iac_coolantleakage' 		=> $request->iac_coolantleakage,
			'iac_brakeoilleakage' 	=> $request->iac_brakeoilleakage,
			'iac_fanbelts' 			=> $request->iac_fanbelts,
			'iac_wiringharmess' 					=> $request->iac_wiringharmess,
			'iac_engineblow' 					=> $request->iac_engineblow,
			'iac_enginenoise' 					=> $request->iac_enginenoise,
			'iac_enginevibration' 					=> $request->iac_enginevibration,
			'iac_enginemounts' 					=> $request->iac_enginemounts,
			'iac_pulleysadjuster' 					=> $request->iac_pulleysadjuster,
			'iac_hoses' 					=> $request->iac_hoses,
			'iac_rediator' 					=> $request->iac_rediator,
			'iac_suctionfan' 					=> $request->iac_suctionfan,
			'iac_exhaustsound' 					=> $request->iac_exhaustsound,
			'iac_starteroperation' 					=> $request->iac_starteroperation,
			'iinitial_token' 			=> $request->iinitial_token,
			'iinitial_id' 				=> $request->iinitial_id,
			'status_id'					=> 1,
			'created_by'				=> $request->userId,
			'created_at'				=> date('Y-m-d h:i:s'),
			);
			if($request->is_edit == 0){
				$save = DB::table('iac')->insert($adds);
			}else{
				$save  = DB::table('iac')
				->where('iinitial_id','=',$request->iinitial_id)
				->update($adds);
			}
		if($save){
			return response()->json(['message' => 'AC Inspection Saved Successfully'],200);
		}else{
			return response()->json("Oops! Something Went Wrong", 400);
		}
	}
	public function savetestdriveinspection(Request $request){
		$validate = Validator::make($request->all(), [ 
		      'itest_enginepick' 			=> 'required',
		      'itest_driveshaftnoice'			=> 'required',
		      'itest_gearshifting' 			=> 'required',
		      'itest_brakepedaloperation'			=> 'required',
		      'itest_absoperation' 		=> 'required',
		      'itest_frontsuspension'		=> 'required',
		      'itest_rearssupension'	=> 'required',
			  'itest_steeringoperation'	=> 'required',
			  'itest_steeringdriving'		=> 'required',
			  'itest_testdrivedoneby'		=> 'required',
			  'iinitial_id'		=> 'required',
			  'iinitial_token'		=> 'required',
			  'is_edit'					=> 'required',
		    ]);
	     	if ($validate->fails()) {    
				return response()->json($validate->errors(), 400);
			}
			$adds = array(
				'itest_enginepick' 	=> $request->itest_enginepick,
				'itest_driveshaftnoice' 			=> $request->itest_driveshaftnoice,
				'itest_gearshifting'				=> $request->itest_gearshifting,
				'itest_brakepedaloperation' 		=> $request->itest_brakepedaloperation,
				'itest_absoperation' 	=> $request->itest_absoperation,
				'itest_frontsuspension' 		=> $request->itest_frontsuspension,
				'itest_rearssupension' 	=> $request->itest_rearssupension,
				'itest_steeringoperation' 		=> $request->itest_steeringoperation,
				'itest_steeringdriving' 		=> $request->itest_steeringdriving,
				'itest_testdrivedoneby' 	=> $request->itest_testdrivedoneby,
				'iinitial_id' 			=> $request->iinitial_id,
				'iinitial_token' 					=> $request->iinitial_token,
				'status_id'					=> 1,
				'created_by'				=> $request->userId,
				'created_at'				=> date('Y-m-d h:i:s'),
			);
			if($request->is_edit == 0){
				$save = DB::table('itest')->insert($adds);
			}else{
				$save  = DB::table('itest')
				->where('iinitial_id','=',$request->iinitial_id)
				->update($adds);
			}
		if($save){
			return response()->json(['message' => 'Test Drive Saved Successfully'],200);
		}else{
			return response()->json("Oops! Something Went Wrong", 400);
		}
	}
	public function savesuspensioninspection(Request $request){
		$validate = Validator::make($request->all(), [ 
		      'iss_steeringwheelplay' 			=> 'required',
		      'iss_rightballoint'			=> 'required',
		      'iss_leftballjoint' 			=> 'required',
		      'iss_rightzlinks'			=> 'required',
		      'iss_leftzlinks' 		=> 'required',
		      'iss_righttierodend'		=> 'required',
		      'iss_lefttierodend'	=> 'required',
			  'iss_frontrightboots'	=> 'required',
			  'iss_frontleftboots'		=> 'required',
			  'iss_frontrightbushes'		=> 'required',
			  'iss_frontleftbushes'		=> 'required',
			  'iss_frontrightshocks'		=> 'required',
			  'iss_frontleftshocks'		=> 'required',
			  'iss_rearrightbushes'		=> 'required',
			  'iss_rearleftbushes'		=> 'required',
			  'iss_rearrightshock'		=> 'required',
			  'iss_rearleftshock'		=> 'required',
			  'iinitial_id'		=> 'required',
			  'iinitial_token'		=> 'required',
			  'is_edit'					=> 'required',
		    ]);
	     	if ($validate->fails()) {    
				return response()->json($validate->errors(), 400);
			}
			$adds = array(
				'iss_steeringwheelplay' 	=> $request->iss_steeringwheelplay,
				'iss_rightballoint' 			=> $request->iss_rightballoint,
				'iss_leftballjoint'				=> $request->iss_leftballjoint,
				'iss_rightzlinks' 		=> $request->iss_rightzlinks,
				'iss_leftzlinks' 	=> $request->iss_leftzlinks,
				'iss_righttierodend' 		=> $request->iss_righttierodend,
				'iss_lefttierodend' 	=> $request->iss_lefttierodend,
				'iss_frontrightboots' 		=> $request->iss_frontrightboots,
				'iss_frontleftboots' 		=> $request->iss_frontleftboots,
				'iss_frontrightbushes' 	=> $request->iss_frontrightbushes,
				'iss_frontleftbushes' 	=> $request->iss_frontleftbushes,
				'iss_frontrightshocks' 	=> $request->iss_frontrightshocks,
				'iss_frontleftshocks' 	=> $request->iss_frontleftshocks,
				'iss_rearrightbushes' 	=> $request->iss_rearrightbushes,
				'iss_rearleftbushes' 	=> $request->iss_rearleftbushes,
				'iss_rearrightshock' 	=> $request->iss_rearrightshock,
				'iss_rearleftshock' 	=> $request->iss_rearleftshock,
				'iinitial_token' 			=> $request->iinitial_token,
				'iinitial_id' 				=> $request->iinitial_id,
				'status_id'					=> 1,
				'created_by'				=> $request->userId,
				'created_at'				=> date('Y-m-d h:i:s'),
			);
			if($request->is_edit == 0){
				$save = DB::table('iss')->insert($adds);
			}else{
				$save  = DB::table('iss')
				->where('iinitial_id','=',$request->iinitial_id)
				->update($adds);
			}
		if($save){
			return response()->json(['message' => 'Suspension Inspection Saved Successfully'],200);
		}else{
			return response()->json("Oops! Something Went Wrong", 400);
		}
	}
	public function savetyreeeinspection(Request $request){
		$validate = Validator::make($request->all(), [ 
		      'ityre_frontrighttyrebrand' 			=> 'required',
		      'ityre_frontrighttyre'			    => 'required',
		      'ityre_frontlefttyrebrand'			=> 'required',
		      'ityre_frontlefttyre' 		        => 'required',
		      'ityre_rearrighttyrebrand'	        => 'required',
			  'ityre_rearrighttyre'	                => 'required',
			  'ityre_rearlefttyrebrand'		        => 'required',
			  'ityre_rearlefttyre'		            => 'required',
			  'ityre_tyresize'		                => 'required',
			  'ityre_rims'		                    => 'required',
			  'ityre_wheelcaps'		                => 'required',
			  'iee_malfunctioncheck'		        => 'required',
			  'iee_batterywarninglight'		        => 'required',
			  'iee_oilpressurelight'		        => 'required',
			  'iee_temperaturewarninglight'		    => 'required',
			  'iee_airbagwarninglight'		        => 'required',
			  'iee_powerstreringwarninglight'		=> 'required',
			  'iee_abswarninglight'		            => 'required',
			  'iee_keyfobbatterylowlight'		    => 'required',
			  'iee_voltage'		                    => 'required',
			  'iee_terminalcondition'		        => 'required',
			  'iee_charging'		                => 'required',
			  'iee_alternatoroperation'		        => 'required',
			  'iee_gauges'		                    => 'required',
			  'iinitial_id'		=> 'required',
			  'iinitial_token'		=> 'required',
			  'is_edit'					=> 'required',
		    ]);
	     	if ($validate->fails()) {    
				return response()->json($validate->errors(), 400);
			}
			$adds = array(
				'ityre_frontrighttyrebrand' 			=> $request->ityre_frontrighttyrebrand,
		      'ityre_frontrighttyre'			    => $request->ityre_frontrighttyre,
		      'ityre_frontlefttyrebrand'			=> $request->ityre_frontlefttyrebrand,
		      'ityre_frontlefttyre' 		        => $request->ityre_frontlefttyre,
		      'ityre_rearrighttyrebrand'	        => $request->ityre_rearrighttyrebrand,
			  'ityre_rearrighttyre'	                => $request->ityre_rearrighttyre,
			  'ityre_rearlefttyrebrand'		        => $request->ityre_rearlefttyrebrand,
			  'ityre_rearlefttyre'		            => $request->ityre_rearlefttyre,
			  'ityre_tyresize'		                => $request->ityre_tyresize,
			  'ityre_rims'		                    => $request->ityre_rims,
			  'ityre_wheelcaps'		                => $request->ityre_wheelcaps,
			  'iinitial_token' 			=> $request->iinitial_token,
			 'iinitial_id' 				=> $request->iinitial_id,
				'status_id'					=> 1,
				'created_by'				=> $request->userId,
				'created_at'				=> date('Y-m-d h:i:s'),
			);
			$adds2 = array(
			  'iee_malfunctioncheck'		        => $request->iee_malfunctioncheck,
			  'iee_batterywarninglight'		        => $request->iee_batterywarninglight,
			  'iee_oilpressurelight'		        => $request->iee_oilpressurelight,
			  'iee_temperaturewarninglight'		    => $request->iee_temperaturewarninglight,
			  'iee_airbagwarninglight'		        => $request->iee_airbagwarninglight,
			  'iee_powerstreringwarninglight'		=> $request->iee_powerstreringwarninglight,
			  'iee_abswarninglight'		            => $request->iee_abswarninglight,
			  'iee_keyfobbatterylowlight'		    => $request->iee_keyfobbatterylowlight,
			  'iee_voltage'		                    => $request->iee_voltage,
			  'iee_terminalcondition'		        => $request->iee_terminalcondition,
			  'iee_charging'		                => $request->iee_charging,
			  'iee_alternatoroperation'		        => $request->iee_alternatoroperation,
			  'iee_gauges'		                    => $request->iee_gauges,
			  'iinitial_token' 			=> $request->iinitial_token,
			 'iinitial_id' 				=> $request->iinitial_id,
			  'status_id'					=> 1,
			  'created_by'				=> $request->userId,
			  'created_at'				=> date('Y-m-d h:i:s'),
			);
			if($request->is_edit == 0){
				$save = DB::table('ityre')->insert($adds);
				$save2 = DB::table('iee')->insert($adds2);
			}else{
				$save  = DB::table('ityre')
				->where('iinitial_id','=',$request->iinitial_id)
				->update($adds);
				$save2  = DB::table('iee')
				->where('iinitial_id','=',$request->iinitial_id)
				->update($adds2);
			}
		if($save && $save2){
			return response()->json(['message' => 'Tyre Electrical & Electronics Inspection Saved Successfully'],200);
		}else{
			return response()->json("Oops! Something Went Wrong", 400);
		}
	}

	public function saveinteriorinspection(Request $request){

		$validate = Validator::make($request->all(), [ 
            'ii_steeringwheelcondition'         => 'required',
            'ii_steeringwheelbuttons'         => 'required',
            'ii_horn'         => 'required',
             'ii_lightleverswitch'         => 'required',
             'ii_wiperwasherlever'         => 'required',
             'ii_interiorlightings'         => 'required',
             'ii_dashcontrolac'         => 'required',
             'ii_dashcontroldefog'         => 'required',
             'ii_hazardlights'         => 'required',
             'ii_parkingbuttons'         => 'required',
             'ii_dashcontrolother'         => 'required',
             'ii_audiovideo'         => 'required',
             'ii_trunkreleselever'         => 'required',
             'ii_fuelcapreleaselever'         => 'required',
             'ii_bonnetreleselever'         => 'required',
             'ii_rightsidemirror'         => 'required',
             'ii_leftsidemirror'         => 'required',
             'ii_rearviewmirrordimmer'         => 'required',
             'ii_rightseatrecliner'         => 'required',
             'ii_leftseatrecliner'         => 'required',
             'ii_rightseatleartrack'         => 'required',
             'ii_leftseatleartrack'         => 'required',
             'ii_rightseatbelt'         => 'required',
             'ii_leftseatbelt'         => 'required',
             'ii_rearseatbelt'         => 'required',
             'ii_glovebox'         => 'required',
             'ii_roofpolish'         => 'required',
             'ii_floormat'         => 'required',
             'ii_frontrighteatpolish'         => 'required',
             'ii_frontleftseatpolish'         => 'required',
             'ii_rearseatpolish'         => 'required',
             'ii_dashboardcondition'         => 'required',
             'ii_frontrightpowerwndow'         => 'required',
             'ii_frontleftpowerwindow'         => 'required',
             'ii_rearrightpowerwindow'         => 'required',
             'ii_rearleftpowerwindow'         => 'required',
             'ii_autolockbutton'         => 'required',
             'ii_windowsafetylock'         => 'required',
             'ii_sparetyre'         => 'required',
             'ii_tools'         => 'required',
             'ii_jack'         => 'required',
			 'iinitial_id'		=> 'required',
             'iinitial_token'		=> 'required',
			 'is_edit'					=> 'required',
		    ]);
	     	if ($validate->fails()) {    
				return response()->json($validate->errors(), 400);
			}
			$adds = array(
                'ii_steeringwheelcondition'         => $request ->ii_steeringwheelcondition,
            'ii_steeringwheelbuttons'         => $request ->ii_steeringwheelbuttons,
            'ii_horn'         => $request ->ii_horn,
             'ii_lightleverswitch'         => $request ->ii_lightleverswitch,
             'ii_wiperwasherlever'         => $request ->ii_wiperwasherlever,
             'ii_interiorlightings'         => $request ->ii_interiorlightings,
             'ii_dashcontrolac'         => $request ->ii_dashcontrolac,
             'ii_dashcontroldefog'         => $request ->ii_dashcontroldefog,
             'ii_hazardlights'         => $request ->ii_hazardlights,
             'ii_parkingbuttons'         => $request ->ii_parkingbuttons,
             'ii_dashcontrolother'         => $request ->ii_dashcontrolother,
             'ii_audiovideo'         => $request ->ii_audiovideo,
             'ii_trunkreleselever'         => $request ->ii_trunkreleselever,
             'ii_fuelcapreleaselever'         => $request ->ii_fuelcapreleaselever,
             'ii_bonnetreleselever'         => $request ->ii_bonnetreleselever,
             'ii_rightsidemirror'         => $request ->ii_rightsidemirror,
             'ii_leftsidemirror'         => $request ->ii_leftsidemirror,
             'ii_rearviewmirrordimmer'         => $request ->ii_rearviewmirrordimmer,
             'ii_rightseatrecliner'         => $request ->ii_rightseatrecliner,
             'ii_leftseatrecliner'         => $request ->ii_leftseatrecliner,
             'ii_rightseatleartrack'         => $request ->ii_rightseatleartrack,
             'ii_leftseatleartrack'         => $request ->ii_leftseatleartrack,
             'ii_rightseatbelt'         => $request ->ii_rightseatbelt,
             'ii_leftseatbelt'         => $request ->ii_leftseatbelt,
             'ii_rearseatbelt'         => $request ->ii_rearseatbelt,
             'ii_glovebox'         => $request ->ii_glovebox,
             'ii_roofpolish'         => $request ->ii_roofpolish,
             'ii_floormat'         => $request ->ii_floormat,
             'ii_frontrighteatpolish'         => $request ->ii_frontrighteatpolish,
             'ii_frontleftseatpolish'         => $request ->ii_frontleftseatpolish,
             'ii_rearseatpolish'         => $request ->ii_rearseatpolish,
             'ii_dashboardcondition'         => $request ->ii_dashboardcondition,
             'ii_frontrightpowerwndow'         => $request ->ii_frontrightpowerwndow,
             'ii_frontleftpowerwindow'         => $request ->ii_frontleftpowerwindow,
             'ii_rearrightpowerwindow'         => $request ->ii_rearrightpowerwindow,
             'ii_rearleftpowerwindow'         => $request ->ii_rearleftpowerwindow,
             'ii_autolockbutton'         => $request ->ii_autolockbutton,
             'ii_windowsafetylock'         => $request ->ii_windowsafetylock,
             'ii_sparetyre'         => $request ->ii_sparetyre,
             'ii_tools'         => $request ->ii_tools,
             'ii_jack'         => $request ->ii_jack,
			 'iinitial_token' 			=> $request->iinitial_token,
			 'iinitial_id' 				=> $request->iinitial_id,
			 'status_id'					=> 1,
			 'created_by'				=> $request->userId,
			 'created_at'				=> date('Y-m-d h:i:s'),
            );
			if($request->is_edit == 0){
				$save = DB::table('iinterior')->insert($adds);
			}else{
				$save  = DB::table('iinterior')
				->where('iinitial_id','=',$request->iinitial_id)
				->update($adds);
			}
	if($save){
			return response()->json(['message' => 'Suspension Inspection Saved Successfully'],200);
		}else{
			return response()->json("Oops! Something Went Wrong", 400);
		}
	}

	public function saveexteriorinspection(Request $request){

		$validate = Validator::make($request->all(), [ 
            'iex_carframe'         => 'required',
            'iex_trunklock'         => 'required',
            'iex_fwindcondition'         => 'required',
             'iex_rwindcondition'         => 'required',
             'iex_frdoorwindow'         => 'required',
             'iex_fldoorwindow'         => 'required',
             'iex_rrightdoorwindow'         => 'required',
             'iex_rleftdoorwindow'         => 'required',
             'iex_windscreenwiper'         => 'required',
             'iex_rheadlightwork'         => 'required',
             'iex_lheadlightwork'         => 'required',
             'iex_rheadlightcondition'         => 'required',
             'iex_lheadlightcondition'         => 'required',
             'iex_rtaillightwork'         => 'required',
             'iex_ltaillightwork'         => 'required',
             'iex_rtaillightcondition'         => 'required',
             'iex_ltaillightcondition'         => 'required',
		    'iex_bonnet'         => 'required',
             'iex_roof'         => 'required',
             'iex_trunk'         => 'required',
             'iex_nearfrontdoor'         => 'required',
             'iex_nearbackdoor'         => 'required',
             'iex_nearfrontwing'         => 'required',
             'iex_nearbackwing'         => 'required',
             'iex_offfrontdoor'         => 'required',
             'iex_offbackdoor'         => 'required',
             'iex_offfrontwing'         => 'required',
             'iex_offbackwing'         => 'required',
			 'is_edit'					=> 'required',
            ]);
	     	if ($validate->fails()) {    
				return response()->json($validate->errors(), 400);
			}
			$adds = array(
            'iex_carframe'         => $request ->iex_carframe,
            'iex_trunklock'         => $request ->iex_trunklock,
            'iex_fwindcondition'         => $request ->iex_fwindcondition,
             'iex_rwindcondition'         => $request ->iex_rwindcondition,
             'iex_frdoorwindow'         => $request ->iex_frdoorwindow,
             'iex_fldoorwindow'         => $request ->iex_fldoorwindow,
             'iex_rrightdoorwindow'         => $request ->iex_rrightdoorwindow,
             'iex_rleftdoorwindow'         => $request ->iex_rleftdoorwindow,
             'iex_windscreenwiper'         => $request ->iex_windscreenwiper,
             'iex_rheadlightwork'         => $request ->iex_rheadlightwork,
             'iex_lheadlightwork'         => $request ->iex_lheadlightwork,
             'iex_rheadlightcondition'         => $request ->iex_rheadlightcondition,
             'iex_lheadlightcondition'         => $request ->iex_lheadlightcondition,
             'iex_rtaillightwork'         => $request ->iex_rtaillightwork,
             'iex_ltaillightwork'         => $request ->iex_ltaillightwork,
             'iex_rtaillightcondition'         => $request ->iex_rtaillightcondition,
             'iex_ltaillightcondition'         => $request ->iex_ltaillightcondition,
             'iex_bonnet'         => $request ->iex_bonnet,
             'iex_roof'         => $request ->iex_roof,
             'iex_trunk'         => $request ->iex_trunk,
             'iex_nearfrontdoor'         => $request ->iex_nearfrontdoor,
             'iex_nearbackdoor'         => $request ->iex_nearbackdoor,
             'iex_nearfrontwing'         => $request ->iex_nearfrontwing,
             'iex_nearbackwing'         => $request ->iex_nearbackwing,
             'iex_offfrontdoor'         => $request ->iex_offfrontdoor,
             'iex_offbackdoor'         => $request ->iex_offbackdoor,
             'iex_offfrontwing'         => $request ->iex_offfrontwing,
             'iex_offbackwing'         => $request ->iex_offbackwing,
			 'iinitial_token' 			=> $request->iinitial_token,
			'iinitial_id' 				=> $request->iinitial_id,
			'status_id'					=> 1,
			'created_by'				=> $request->userId,
			'created_at'				=> date('Y-m-d h:i:s'),
			);
			if($request->is_edit == 0){
				$save = DB::table('iexterior')->insert($adds);
			}else{
				$save  = DB::table('iexterior')
				->where('iinitial_id','=',$request->iinitial_id)
				->update($adds);
			}
		if($save){
			return response()->json(['message' => 'Exterior Inspection Saved Successfully'],200);
		}else{
			return response()->json("Oops! Something Went Wrong", 400);
		}
	}

	public function inspectionreport(Request $request){
		$validate = Validator::make($request->all(), [ 
		      'iinitial_token' 			=> 'required',
		    ]);
	     	if ($validate->fails()) {    
				return response()->json($validate->errors(), 400);
			}
			$initial = DB::table('iinitial')
			->select('*')
			->where('status_id','=',1)
			->where('iinitial_token','=',$request->iinitial_token)
			->first();
			$body = DB::table('ibody')
			->select('*')
			->where('status_id','=',1)
			->where('iinitial_token','=',$request->iinitial_token)
			->first();
			$interior = DB::table('iinterior')
			->select('*')
			->where('status_id','=',1)
			->where('iinitial_token','=',$request->iinitial_token)
			->first();
			$ac = DB::table('iac')
			->select('*')
			->where('status_id','=',1)
			->where('iinitial_token','=',$request->iinitial_token)
			->first();
			$test = DB::table('itest')
			->select('*')
			->where('status_id','=',1)
			->where('iinitial_token','=',$request->iinitial_token)
			->first();
			$suspention = DB::table('iss')
			->select('*')
			->where('status_id','=',1)
			->where('iinitial_token','=',$request->iinitial_token)
			->first();
			$tyre = DB::table('ityre')
			->select('*')
			->where('status_id','=',1)
			->where('iinitial_token','=',$request->iinitial_token)
			->first();
			$electrical = DB::table('iee')
			->select('*')
			->where('status_id','=',1)
			->where('iinitial_token','=',$request->iinitial_token)
			->first();
			$exterior = DB:: table('iexterior')
			->select('*')
			->where('status_id', '=', 1)
			->where('iinitial_token', '=', $request->iinitial_token)
			->first();
			
			$gallery = DB::table('inspectiondetail')
			->select('inspectionimage_name','inspectionstep_name')
			->where('iinitial_token','=',$request->iinitial_token)
			->where('inspectionstep_id','=',1)
			->where('status_id','=',1)
			->get();
			$cover = DB::table('inspectiondetail')
			->select('inspectionimage_name')
			->where('iinitial_token','=',$request->iinitial_token)
			->where('inspectionstep_id','=',1)
			->where('inspectionimage_placement','=',"iinitial_frontimage")
			->where('status_id','=',1)
			->first();
			// carimage
			$bonnetimage = DB::table('inspectiondetail')
			->select('inspectionimage_name','inspectionstep_name')
			->where('iinitial_token','=',$request->iinitial_token)
			->where('inspectionstep_id','=',9)
			->where('inspectionimage_placement','=',"iex_bonnetimage")
			->where('status_id','=',1)
			->first();
			$roofimage = DB::table('inspectiondetail')
			->select('inspectionimage_name','inspectionstep_name')
			->where('iinitial_token','=',$request->iinitial_token)
			->where('inspectionstep_id','=',9)
			->where('inspectionimage_placement','=',"iex_roofimage")
			->where('status_id','=',1)
			->first();
			$trunkimage = DB::table('inspectiondetail')
			->select('inspectionimage_name','inspectionstep_name')
			->where('iinitial_token','=',$request->iinitial_token)
			->where('inspectionstep_id','=',9)
			->where('inspectionimage_placement','=',"iex_trunkimage")
			->where('status_id','=',1)
			->first();
			$offfrontwingimage = DB::table('inspectiondetail')
			->select('inspectionimage_name','inspectionstep_name')
			->where('iinitial_token','=',$request->iinitial_token)
			->where('inspectionstep_id','=',9)
			->where('inspectionimage_placement','=',"iex_offfrontwingimage")
			->where('status_id','=',1)
			->first();
			$offfrontdoorimage = DB::table('inspectiondetail')
			->select('inspectionimage_name','inspectionstep_name')
			->where('iinitial_token','=',$request->iinitial_token)
			->where('inspectionstep_id','=',9)
			->where('inspectionimage_placement','=',"iex_offfrontdoorimage")
			->where('status_id','=',1)
			->first();
			$offbackdoorimage = DB::table('inspectiondetail')
			->select('inspectionimage_name','inspectionstep_name')
			->where('iinitial_token','=',$request->iinitial_token)
			->where('inspectionstep_id','=',9)
			->where('inspectionimage_placement','=',"iex_offbackdoorimage")
			->where('status_id','=',1)
			->first();
			$offbackwingimage = DB::table('inspectiondetail')
			->select('inspectionimage_name','inspectionstep_name')
			->where('iinitial_token','=',$request->iinitial_token)
			->where('inspectionstep_id','=',9)
			->where('inspectionimage_placement','=',"iex_offbackwingimage")
			->where('status_id','=',1)
			->first();
			$nearfrontwingimage = DB::table('inspectiondetail')
			->select('inspectionimage_name','inspectionstep_name')
			->where('iinitial_token','=',$request->iinitial_token)
			->where('inspectionstep_id','=',9)
			->where('inspectionimage_placement','=',"iex_nearfrontwingimage")
			->where('status_id','=',1)
			->first();
			$nearfrontdoorimage = DB::table('inspectiondetail')
			->select('inspectionimage_name','inspectionstep_name')
			->where('iinitial_token','=',$request->iinitial_token)
			->where('inspectionstep_id','=',9)
			->where('inspectionimage_placement','=',"iex_nearfrontdoorimage")
			->where('status_id','=',1)
			->first();
			$nearbackdoorimage = DB::table('inspectiondetail')
			->select('inspectionimage_name','inspectionstep_name')
			->where('iinitial_token','=',$request->iinitial_token)
			->where('inspectionstep_id','=',9)
			->where('inspectionimage_placement','=',"iex_nearbackdoorimage")
			->where('status_id','=',1)
			->first();
			$nearbackwingimage = DB::table('inspectiondetail')
			->select('inspectionimage_name','inspectionstep_name')
			->where('iinitial_token','=',$request->iinitial_token)
			->where('inspectionstep_id','=',9)
			->where('inspectionimage_placement','=',"iex_nearbackwingimage")
			->where('status_id','=',1)
			->first();
			$bodyPercentage=$this->bodyPercentage($body);
			$interiorPercentage=$this->interiorPercentage($interior);
			$acPercentage=$this->acPercentage($ac);
			$testPercentage=$this->testPercentage($test);
			$suspentionPercentage=$this->suspentionPercentage($suspention);
			$tyrePercentage=$this->tyrePercentage($tyre);
			$electricalPercentage=$this->electricalPercentage($electrical);
			$exteriorPercentage=$this->exteriorPercentage($exterior);
			$brakePercentage=$this->brakePercentage($body);
			

			$total =($bodyPercentage+$interiorPercentage+$acPercentage+$testPercentage+$suspentionPercentage+$tyrePercentage+$electricalPercentage+$brakePercentage+$exteriorPercentage)/(900)*100;
		    $gallerypath = URL::to( '/' ).'/public'.'/iinitial'.'/'.$initial->iinitial_token.'/';
		    $scatchpath = URL::to( '/' ).'/public'.'/iexterior'.'/'.$initial->iinitial_token.'/';
			
		if($initial){
			return response()->json(['initial' => $initial, 'body' => $body, 'interior' => $interior,
			 'ac'=> $ac, 'test' => $test, 'suspention' => $suspention, 'tyre' => $tyre,
			  'electrical' => $electrical, 'exterior' => $exterior, 'bodyPercentage' => $bodyPercentage,
			   'interiorPercentage' => $interiorPercentage,'acPercentage' => $acPercentage,
			   'testPercentage' => $testPercentage,'suspentionPercentage' => $suspentionPercentage, 
			   'tyrePercentage' => $tyrePercentage, 'electricalPercentage' => $electricalPercentage,
			'exteriorPercentage' => $exteriorPercentage,
			'brakePercentage' => $brakePercentage,'gallery' => $gallery,'cover' => $cover,
			'bonnetimage' => $bonnetimage, 'roofimage' => $roofimage, 'trunkimage' => $trunkimage,
 			'offfrontwingimage' => $offfrontwingimage, 'offfrontdoorimage' => $offfrontdoorimage,
  			'offbackdoorimage' => $offbackdoorimage, 'offbackwingimage' => $offbackwingimage,
  			'nearfrontwingimage' => $nearfrontwingimage, 'nearfrontdoorimage' => $nearfrontdoorimage,
 		 'nearbackdoorimage' => $nearbackdoorimage, 'nearbackwingimage' => $nearbackwingimage,
			'gallerypath' => $gallerypath, 'scatchpath' => $scatchpath,
			'total' => round($total), 'message' => 'Inspection Reporty'],200);
		}else{
			return response()->json("Oops! Something Went Wrong", 400);
		}
	}
	public function inspectionlist(Request $request){
		$initial = DB::table('inspectionlist')
		->select('*')
		->where('status_id','=',1)
		->get();
		if($initial){
			return response()->json(['initial' => $initial, 'message' => 'Inspection List'],200);
		}else{
			return response()->json("Oops! Something Went Wrong", 400);
		}
	}

	public function bodyPercentage($body){
		$bodyPercentage=0;

		$bodyPercentage+=$body->ibody_rediatorcore=="Accident"?0:1;
		$bodyPercentage+=$body->ibody_leftstruttowerapron=="Accident"?0:1;
		$bodyPercentage+=$body->ibody_leftfrontrail=="Accident"?0:1;
		$bodyPercentage+=$body->ibody_bootlockpillar=="Accident"?0:1;
		$bodyPercentage+=$body->ibody_frontsubframe=="Accident"?0:1;
		$bodyPercentage+=$body->ibody_rightapillar=="Accident"?0:1;
		$bodyPercentage+=$body->ibody_rightbpillar=="Accident"?0:1;
		$bodyPercentage+=$body->ibody_rightcpillar=="Accident"?0:1;
		$bodyPercentage+=$body->ibody_rightdpillar=="Accident"?0:1;
		$bodyPercentage+=$body->ibody_rightstruttowerapron=="Accident"?0:1;
		$bodyPercentage+=$body->ibody_rightfrontrail=="Accident"?0:1;
		$bodyPercentage+=$body->ibody_bootfloor=="Accident"?0:1;
		$bodyPercentage+=$body->ibody_rearsubframe=="Accident"?0:1;
		$bodyPercentage+=$body->ibody_cowlpanelfirewall=="Accident"?0:1;
		$bodyPercentage+=$body->ibody_leftapillar=="Accident"?0:1;
		$bodyPercentage+=$body->ibody_leftbpillar=="Accident"?0:1;
		$bodyPercentage+=$body->ibody_leftcpillar=="Accident"?0:1;
		$bodyPercentage+=$body->ibody_leftdpillar=="Accident"?0:1;
	
		$bodyPercentage=$bodyPercentage/(18)*100;
		return round($bodyPercentage);
	}

	public function brakePercentage($body){
		$brakePercentage=0;

		$brakePercentage+=$body->ibody_frontrightdisc=="Rough"?0:1;
		$brakePercentage+=$body->ibody_frontleftdisc=="Rough"?0:1;
		$brakePercentage+=$body->ibody_frontrightbrakepad=="less than 50%"?0:1;
		$brakePercentage+=$body->ibody_frontleftbrakepad=="less than 50%"?0:1;

		$brakePercentage=$brakePercentage/(4)*100;
		return round($brakePercentage);
	}

	public function interiorPercentage($interior){
	$interiorPercentage=0;

	$interiorPercentage+=$interior->ii_steeringwheelcondition=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_steeringwheelbuttons=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_horn=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_lightleverswitch=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_wiperwasherlever=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_interiorlightings=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_dashcontrolac=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_dashcontroldefog=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_hazardlights=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_parkingbuttons=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_dashcontrolother=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_audiovideo=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_trunkreleselever=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_fuelcapreleaselever=="No Damage Found"?1:0;
	$interiorPercentage+=$interior->ii_bonnetreleselever=="No Damage Found"?1:0;
	$interiorPercentage+=$interior->ii_rightsidemirror=="No Damage Found"?1:0;
	$interiorPercentage+=$interior->ii_leftsidemirror=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_rearviewmirrordimmer=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_rightseatrecliner=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_leftseatrecliner=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_rightseatleartrack=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_leftseatleartrack=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_rightseatbelt=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_leftseatbelt=="Ok"?1:0;
	$interiorPercentage+=$interior->iiior_rearseatbelt=="Ok"?1:0;
	$interiorPercentage+=$interior->iiterior_glovebox=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_roofpolish=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_floormat=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_frontrighteatpolish=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_frontleftseatpolish=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_rearseatpolish=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_dashboardcondition=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_frontrightpowerwndow=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_frontleftpowerwindow=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_rearrightpowerwindow=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_rearleftpowerwindow=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_autolockbutton=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_windowsafetylock=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_sparetyre=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_tools=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_jack=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_rearseatbelt=="Ok"?1:0;
	$interiorPercentage+=$interior->ii_glovebox=="Ok"?1:0;
	
	$interiorPercentage =$interiorPercentage/(43)*100;
	return round($interiorPercentage);
	}

	public function acPercentage($ac){
		$acPercentage=0;

		$acPercentage+=$ac->iac_acfitted=="Yes"?1:0;
		$acPercentage+=$ac->iac_acoperational=="Yes"?1:0;
		if($ac->iac_blower=="Excellent Air Throw"){
			$acPercentage+=1;
		}else if($ac->iac_blower=="Good Air Throw"){
			$acPercentage+=0.5;
		} 
		if($ac->iac_cooling=="Excellent"){
			$acPercentage+=1;
		}else if($ac->iac_cooling=="Good"){
			$acPercentage+=0.5;
		} 
		if($ac->iac_heating=="Excellent"){
			$acPercentage+=1;
		}else if($ac->iac_heating=="Good"){
			$acPercentage+=0.5;
		} 
		$acPercentage+=$ac->iac_engineoillevel=="Complete and Clean"?1:0;
		$acPercentage+=$ac->iac_engineoilleakage=="No Leakage"?1:0;
		$acPercentage+=$ac->iac_transmissionoilleakage=="No Leakage"?1:0;
		$acPercentage+=$ac->iac_coolantleakage=="No Leakage"?1:0;
		$acPercentage+=$ac->iac_brakeoilleakage=="No Leakage"?1:0;
		$acPercentage+=$ac->iac_fanbelts=="Ok"?1:0;
		$acPercentage+=$ac->iac_wiringharmess=="Ok"?1:0;
		$acPercentage+=$ac->iac_engineblow=="Not Present"?1:0;
		$acPercentage+=$ac->iac_enginenoise=="No Noise"?1:0;
		$acPercentage+=$ac->iac_enginevibration=="No Vibration"?1:0;
		$acPercentage+=$ac->iac_enginemounts=="Ok"?1:0;
		$acPercentage+=$ac->iac_pulleysadjuster=="Ok"?1:0;
		$acPercentage+=$ac->iac_hoses=="Ok"?1:0;
		$acPercentage+=$ac->iac_rediator=="Ok"?1:0;
		$acPercentage+=$ac->iac_suctionfan=="Working"?1:0;
		$acPercentage+=$ac->iac_exhaustsound=="Ok"?1:0;
		$acPercentage+=$ac->iac_starteroperation=="Ok"?1:0;

		$acPercentage=$acPercentage/(22)*100;
		return round($acPercentage);

	}
	public function testPercentage($test){
		$testPercentage=0;

		$testPercentage+=$test->itest_enginepick=="Ok"?1:0;
		$testPercentage+=$test->itest_driveshaftnoice=="No Noise"?1:0;
		$testPercentage+=$test->itest_gearshifting=="Smooth"?1:0;
		$testPercentage+=$test->itest_brakepedaloperation=="Timely Response"?1:0;
		$testPercentage+=$test->itest_absoperation=="Timely Response"?1:0;
		$testPercentage+=$test->itest_frontsuspension=="No Noise"?1:0;
		$testPercentage+=$test->itest_rearssupension=="No Noise"?1:0;
		$testPercentage+=$test->itest_steeringoperation=="Smooth"?1:0;
		$testPercentage+=$test->itest_steeringdriving=="Centered"?1:0;
		$testPercentage+=$test->itest_acoperation=="Perfect"?1:0;
		$testPercentage+=$test->itest_heateroperation=="Perfect"?1:0;
		$testPercentage+=$test->itest_speedometer=="Working"?1:0;

		$testPercentage=$testPercentage/(12)*100;
		return round($testPercentage);

	}
	public function suspentionPercentage($suspention){
		$suspentionPercentage=0;

		$suspentionPercentage+=$suspention->iss_steeringwheelplay=="Ok"?1:0;
		$suspentionPercentage+=$suspention->iss_rightballoint=="Ok"?1:0;
		$suspentionPercentage+=$suspention->iss_leftballjoint=="Ok"?1:0;
		$suspentionPercentage+=$suspention->iss_rightzlinks=="Ok"?1:0;
		$suspentionPercentage+=$suspention->iss_leftzlinks=="Ok"?1:0;
		$suspentionPercentage+=$suspention->iss_righttierodend=="Ok"?1:0;
		$suspentionPercentage+=$suspention->iss_lefttierodend=="Ok"?1:0;
		$suspentionPercentage+=$suspention->iss_frontrightboots=="Ok"?1:0;
		$suspentionPercentage+=$suspention->iss_frontleftboots=="Ok"?1:0;
		$suspentionPercentage+=$suspention->iss_frontrightbushes=="Ok"?1:0;
		$suspentionPercentage+=$suspention->iss_frontleftbushes=="Ok"?1:0;
		$suspentionPercentage+=$suspention->iss_frontrightshocks=="Ok"?1:0;
		$suspentionPercentage+=$suspention->iss_frontleftshocks=="Ok"?1:0;
		$suspentionPercentage+=$suspention->iss_rearrightbushes=="No Damage Found"?1:0;
		$suspentionPercentage+=$suspention->iss_rearleftbushes=="No Damage Found"?1:0;
		$suspentionPercentage+=$suspention->iss_rearrightshock=="Ok"?1:0;
		$suspentionPercentage+=$suspention->iss_rearleftshock=="Ok"?1:0;

		$suspentionPercentage=$suspentionPercentage/(17)*100;
		return round($suspentionPercentage);

	}
	public function tyrePercentage($tyre){
		$tyrePercentage=0;

		$tyrePercentage+=$tyre->ityre_frontrighttyre=="Ok"?1:0;
		$tyrePercentage+=$tyre->ityre_frontlefttyre=="Ok"?1:0;
		$tyrePercentage+=$tyre->ityre_rearrighttyre=="Ok"?1:0;
		$tyrePercentage+=$tyre->ityre_rearlefttyre=="Ok"?1:0;
		$tyrePercentage+=$tyre->ityre_rims=="Ok"?1:0;
		$tyrePercentage+=$tyre->ityre_wheelcaps=="Ok"?1:0;

		$tyrePercentage=$tyrePercentage/(6)*100;
		return round($tyrePercentage);

	}
	public function electricalPercentage($electrical){
		$electricalPercentage=0;

		$electricalPercentage+=$electrical->iee_malfunctioncheck=="Ok"?1:0;
		$electricalPercentage+=$electrical->iee_batterywarninglight=="Ok"?1:0;
		$electricalPercentage+=$electrical->iee_oilpressurelight=="No Damage Found"?1:0;
		$electricalPercentage+=$electrical->iee_temperaturewarninglight=="No Damage Found"?1:0;
		$electricalPercentage+=$electrical->iee_airbagwarninglight=="No Damage Found"?1:0;
		$electricalPercentage+=$electrical->iee_powerstreringwarninglight=="Ok"?1:0;
		$electricalPercentage+=$electrical->iee_abswarninglight=="Ok"?1:0;
		$electricalPercentage+=$electrical->iee_keyfobbatterylowlight=="Ok"?1:0;
		$electricalPercentage+=$electrical->iee_voltage=="Ok"?1:0;
		$electricalPercentage+=$electrical->iee_terminalcondition=="Ok"?1:0;
		$electricalPercentage+=$electrical->iee_charging=="Ok"?1:0;
		$electricalPercentage+=$electrical->iee_alternatoroperation=="Ok"?1:0;
		$electricalPercentage+=$electrical->iee_gauges=="Ok"?1:0;

		$electricalPercentage=$electricalPercentage/(13)*100;
		return round($electricalPercentage);

	}

	public function exteriorPercentage($exterior){
		$exteriorPercentage=0;

		$exteriorPercentage+=$exterior->iex_carframe=="Ok"?1:0;
		$exteriorPercentage+=$exterior->iex_trunklock=="Ok"?1:0;
		$exteriorPercentage+=$exterior->iex_fwindcondition=="Ok"?1:0;
		$exteriorPercentage+=$exterior->iex_rwindcondition=="Ok"?1:0;
		$exteriorPercentage+=$exterior->iex_frdoorwindow=="Ok"?1:0;
		$exteriorPercentage+=$exterior->iex_fldoorwindow=="Ok"?1:0;
		$exteriorPercentage+=$exterior->iex_rrightdoorwindow=="Ok"?1:0;
		$exteriorPercentage+=$exterior->iex_rleftdoorwindow=="Ok"?1:0;
		$exteriorPercentage+=$exterior->iex_windscreenwiper=="Cleaning Property"?1:0;
		$exteriorPercentage+=$exterior->iex_rheadlightwork=="Working"?1:0;
		$exteriorPercentage+=$exterior->iex_lheadlightwork=="Working"?1:0;
		$exteriorPercentage+=$exterior->iex_rheadlightcondition=="Perfect"?1:0;
		$exteriorPercentage+=$exterior->iex_lheadlightcondition=="Perfect"?1:0;
		$exteriorPercentage+=$exterior->iex_rtaillightwork=="Working"?1:0;
		$exteriorPercentage+=$exterior->iex_ltaillightwork=="Working"?1:0;
		$exteriorPercentage+=$exterior->iex_rtaillightcondition=="Perfect"?1:0;
		$exteriorPercentage+=$exterior->iex_ltaillightcondition=="Perfect"?1:0;

		$exteriorPercentage=$exteriorPercentage/(17)*100;
		return round($exteriorPercentage);

	}
}