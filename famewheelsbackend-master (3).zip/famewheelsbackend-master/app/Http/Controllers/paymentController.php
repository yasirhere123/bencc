<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\File;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Http;
use Kreait\Firebase;
use Kreait\Firebase\Factory;
use GuzzleHttp\Client;
use Image;
use DB;
use Input;
use Session;
use Response;
use Validator;
use URL;

class paymentController extends Controller {
    public function memberpayment( Request $request ) {
        // Production/Sandbox Credentials
        // $MerchantID    = 'MC56944';
        $MerchantID    = '87876565';
        //Live Your Merchant from transaction Credentials

        // $Password      = '0b4ydtea9t';
        $Password      = 'ssszc65y15';
        //Live Your Password from transaction Credentials

        $HashKey = '';
        //Your HashKey/integrity salt from transaction Credentials

        $ReturnURL     = 'https://onlinepayment.famewheels.com/responsepayment';
        //Your Return URL, It must be static

        // *** for sandbox testing environment

        // $PostURL = 'https://sandbox.jazzcash.com.pk/CustomerPortal/transactionmanagement/merchantform/';

        // *** for production environment

        $PostURL = 'https://payments.jazzcash.com.pk/CustomerPortal/transactionmanagement/merchantform';

        date_default_timezone_set( 'Asia/karachi' );

        $Amount = $request->amount * 100;
        //Last two digits will be considered as Decimal

        $BillReference = 'billRef';
        //use AlphaNumeric only

        $Description = 'Fame Wheels Bidding Membership';
        //use AlphaNumeric only

        $IsRegisteredCustomer = 'No';
        // do not change it

        $Language = 'EN';
        // do not change it

        $TxnCurrency = 'PKR';
        // do not change it ( JAZZCASH Payment gateway only deals in ‘PKR’ )

        $TxnDateTime = date( 'YmdHis' );

        $TxnExpiryDateTime = date( 'YmdHis', strtotime( '+1 Days' ) );

        $TxnRefNumber = 'fam' . date( 'YmdHis' ) . mt_rand( 10, 100 );
        // You can customize it ( only Max 20 Alpha-Numeric characters )

        $TxnType = '';
        // Leave it empty

        $Version = '2.0';

        $SubMerchantID = '';
        // Leave it empty

        $BankID = '';
        // Leave it empty

        $ProductID = '';
        // Leave it empty

        $ppmpf_1 = '';
        // use to store extra details ( use AlphaNumeric only )

        $ppmpf_2 = '';
        // use to store extra details ( use AlphaNumeric only )

        $ppmpf_3 = '';
        // use to store extra details ( use AlphaNumeric only )

        $ppmpf_4 = '';
        // use to store extra details ( use AlphaNumeric only )

        $ppmpf_5 = '';
        // use to store extra details ( use AlphaNumeric only )
        $HashKey = 'ue19u14273';
        // Live Hash
        // $HashKey = '034298d8a4';
        $HashArray = [ $HashKey, $Amount, $BankID, $BillReference, $Description, $IsRegisteredCustomer, $Language, $MerchantID, $Password, $ProductID, $ReturnURL, $TxnCurrency, $TxnDateTime, $TxnExpiryDateTime, $TxnRefNumber, $TxnType, $Version];

        $SortedArray = '';
       

        for ( $i = 0; $i < count( $HashArray ); $i++ ) {

            if ( $HashArray[ $i ] != 'undefined' and $HashArray[ $i ] != null and $HashArray[ $i ] != '' ) {
                if($i == 0){
                    $SortedArray .= $HashArray[ $i ];
                }else{
                    $SortedArray .= '&' . $HashArray[ $i ];
                }

            }

        }
       

        $Securehash = hash_hmac( 'sha256', $SortedArray, $HashKey );

        $values = [
            'pp_Version' => $Version,
            'pp_TxnType' => $TxnType,
            'pp_SubMerchantID' => $SubMerchantID,
            'pp_TxnRefNo' => $TxnRefNumber,
            'pp_Amount' => $Amount,
            'pp_TxnDateTime' => $TxnDateTime,
            'pp_IsRegisteredCustomer' => $IsRegisteredCustomer,
            'pp_BankID' => $BankID,
            'pp_ProductID' => $ProductID,
            'pp_TxnExpiryDateTime' => $TxnExpiryDateTime,
            'pp_ReturnURL' => $ReturnURL,
        ];

        return $values;
    }

    public function responsepayment() {
        if(isset($_POST[ 'pp_ResponseCode' ])){
            $HashKey = 'ue19u14273';
            $ResponseCode = $_POST[ 'pp_ResponseCode' ];
            $ResponseMessage = $_POST[ 'pp_ResponseMessage' ];
            $Response = '';
            $comment = '';
            $ReceivedSecureHash = $_POST[ 'pp_SecureHash' ];
            $sortedResponseArray = array();
            if ( !empty( $_POST ) ) {
                foreach ( $_POST as $key => $val ) {
                    $comment .= $key . '[' . $val . '],<br/>';
                    $sortedResponseArray[ $key ] = $val;
                }
            }
            ksort( $sortedResponseArray );

            unset( $sortedResponseArray[ 'pp_SecureHash' ] );
            $Response = $HashKey;
            foreach ( $sortedResponseArray as $key => $val ) {

                if ( $val != null and $val != '' ) {
                    $Response .= '&'.$val;

                }
            }
            $GeneratedSecureHash = hash_hmac( 'sha256', $Response, $HashKey );
            if ( strtolower( $GeneratedSecureHash ) == strtolower( $ReceivedSecureHash ) ) {
                $txnRefNo = $_POST[ 'pp_TxnRefNo' ];
                // $reqAmount = $_POST[ 'pp_Amount' ]/100;
                $reqAmount = 30000;
                $reqDatetime = $_POST[ 'pp_TxnDateTime' ];
                $reqBillref = $_POST[ 'pp_BillReference' ];
                $reqRetrivalRefNo = $_POST[ 'pp_RetreivalReferenceNo' ];
                $SecureHash = $_POST[ 'pp_SecureHash' ];
                if ( $ResponseCode == '000' || $ResponseCode == '121' || $ResponseCode == '200' ) {
                    $values = [
                        // 'amount' => $reqAmount,
                        // 'orderid' => $txnRefNo,
                        'responsecode' => $ResponseCode,
                        'ResponseMessage' => $ResponseMessage,
                        // 'SecureHash' => $SecureHash,
                    ];
                    $queryParameters = http_build_query($values);
                    $ppmpf_1 = str_replace( ',', '', $_POST[ 'ppmpf_1' ]);
                    $ppmpf_2 = str_replace( ',', '', $_POST[ 'ppmpf_2' ]);
                    $ppmpf_3 = str_replace( ',', '', $_POST[ 'ppmpf_3' ]);
                    $ppmpf_4 = str_replace( ',', '', $_POST[ 'ppmpf_4' ]);
                    $ppmpf_5 = str_replace( ',', '', $_POST[ 'ppmpf_5' ]);
                    
                    $userData = array(
                        "name" => $ppmpf_1,
                        "email" => $ppmpf_2,
                        "password" => $ppmpf_5,
                        "phone" => $ppmpf_3,
                        "CNIC" => $ppmpf_4,
                        "roleName" => "ROLE_BIDDER"
                    );
                    $sortdata = json_encode($userData);
                    $data = array(
                        'userData' => $sortdata,
                        'SecurityDeposit' => $reqAmount,
                        'paymentMethod' => 'jazz-cash',
                        'orderId' => $txnRefNo,
                        'paymentToken' => $SecureHash
                    );
                    
                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => 'https://portal.famewheels.com/fame/createMember',
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => '',
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 0,
                        CURLOPT_FOLLOWLOCATION => true,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => 'POST',
                        CURLOPT_POSTFIELDS => http_build_query($data),
                    ));
                    
                    $response = curl_exec($curl);
                    curl_close($curl);
                    $redirectUrl = 'https://famewheels.com/become-a-member?' . $queryParameters;
                    return redirect()->away($redirectUrl);
                } else  if ( $ResponseCode == '124' || $ResponseCode == '210' || $ResponseCode == '157' ) {
                    if ( $ResponseCode == '124' ) {
                        $values = [
                            'responsecode' => $ResponseCode,
                            'ResponseMessage' => $ResponseMessage,
                        ];
                        $queryParameters = http_build_query($values);
                        $redirectUrl = 'https://famewheels.com/become-a-member?' . $queryParameters;
                        return redirect()->away($redirectUrl);
                    }
                    $values = [
                        'responsecode' => $ResponseCode,
                        'ResponseMessage' => $ResponseMessage,
                    ];
                    $queryParameters = http_build_query($values);
                    $redirectUrl = 'https://famewheels.com/become-a-member?' . $queryParameters;
                    return redirect()->away($redirectUrl);
                } else {
                    $values = [
                        'responsecode' => $ResponseCode,
                        'ResponseMessage' => $ResponseMessage,
                    ];
                    $queryParameters = http_build_query($values);
                    $redirectUrl = 'https://famewheels.com/become-a-member?' . $queryParameters;
                    return redirect()->away($redirectUrl);
                }

            } else {
                $values = [
                    'responsecode' => 210,
                    'ResponseMessage' => "mismatched, marked it suspicious or reject it",
                ];
                $queryParameters = http_build_query($values);
                $redirectUrl = 'https://famewheels.com/become-a-member?' . $queryParameters;
                return redirect()->away($redirectUrl);
            }
        }else{
            $values = [
                'responsecode' => 210,
                'ResponseMessage' => "mismatched, marked it suspicious or reject it",
            ];
            $queryParameters = http_build_query($values);
            $redirectUrl = 'https://famewheels.com/become-a-member?' . $queryParameters;
            return redirect()->away($redirectUrl);
        }
    }
    public  function generateRandomString( $length = 20 ) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen( $characters );
        $randomString = '';
        for ( $i = 0; $i < $length; $i++ ) {
            $randomString .= $characters[ rand( 0, $charactersLength - 1 ) ];
        }
        return $randomString;
    }
    public  function inquirypayment(Request $request) {
        $MerchantID    = "MC56944";
        $Password      = "0b4ydtea9t";
        $HashKey = '034298d8a4';
        $TxnRefNumber = $request->orderId;
        $salt = "034298d8a4";
        $HashArray = $salt.'&'.$MerchantID.'&'.$Password.'&'.$TxnRefNumber;
        $Securehash = hash_hmac( 'sha256', $HashArray, $HashKey );
      
        $data = array(
            'pp_MerchantID' => $MerchantID,
            'pp_Password' => $Password,
            'pp_TxnRefNo' => $TxnRefNumber,
            'pp_SecureHash' => $Securehash,
        );
        
        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://sandbox.jazzcash.com.pk/ApplicationAPI/API/PaymentInquiry/Inquire',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => http_build_query($data),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $response = json_decode($response);
        if($response->pp_ResponseCode == '000' || $response->pp_ResponseCode == '121' || $response->pp_ResponseCode == '200'){
            return response()->json($response,200);
        }else{
            return response()->json($response,400);
        }
    }
}