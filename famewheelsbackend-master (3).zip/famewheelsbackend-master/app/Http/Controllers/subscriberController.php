<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\File;
use Tymon\JWTAuth\Exceptions\JWTException;
use JWTAuth;
use Image;
use DB;
use Input;
use App\Item;
use App\Models\User;
use Session;
use Response;
use Validator;
use URL;

class subscriberController extends Controller {
    public function savesubscriber( Request $request ) {
        $validate = Validator::make( $request->all(), [
            'subscriber_name'	    => 'required',
            'subscriber_email'	    => 'required',
            'subscriber_phone'	    => 'required',
        ] );
        if ( $validate->fails() ) {
            return response()->json( $validate->errors(), 400 );
        }
        $data = [
            'subscriber_name'       => $request->subscriber_name,
            'email'                 => $request->subscriber_email,
            'subscriber_phone'      => $request->subscriber_phone,
            'subscriber_date'       => date( 'Y-m-d' ),
        ];
        $save = DB::table( 'subscribers' )->insert( $data );
        if ( $save ) {
            return response()->json( [ 'message' => 'Subscriber Saved Successfully' ], 200 );
        } else {
            return response()->json( [ 'message' => 'Oops! something went wrong' ], 200 );
        }
    }
}