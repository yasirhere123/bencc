<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\File;
use Tymon\JWTAuth\Exceptions\JWTException;
use JWTAuth;
use Image;
use DB;
use Input;
use App\Item;
use App\Models\User;
use Session;
use Response;
use Validator;
use URL;

class webController extends Controller {
    public function saveevent( Request $request ) {
        $validate = Validator::make( $request->all(), [
            'post_content' 	    => 'required',
            'post_title'	    => 'required',
            'post_image'	    => 'required',
            'start_date'	    => 'required',
            'end_date' 	        => 'required',
            'timezone'	        => 'required',
            'duration'	        => 'required',
        ] );
        if ( $validate->fails() ) {
            return response()->json( $validate->errors(), 200 );
        }
        if( $request->post_image->isValid()){
            $destinationPath = 'wp-content/uploads/'.date('Y').'/'.date('m').'/';
            if (!file_exists($destinationPath)) {
                mkdir($destinationPath, 0755, true);
            }
			$number = rand(1,999);
			$numb = $number / 7 ;
			$name = "post_image";
			$extension = $request->post_image->extension();
			$image_name  = date('Y-m-d')."_".$numb."_".$name."_.".$extension;
			$imageresize = $request->post_image->move($destinationPath, $image_name);
        	$img = Image::make($imageresize)->resize(800,800, function($constraint) {
					$constraint->aspectRatio();
			});
			$img->save($imageresize);
		}else{
			return response()->json("Invalid Format", 400);
		}
		$adds[] = array(
            'post_date'		    => date('Y-m-d h:i:s'),
            'post_date_gmt'		=> date('Y-m-d h:i:s'),
            'post_content' 		=> $request->post_content,
            'post_title'		=> $request->post_title,
            'post_name'		    => str_slug($request->post_title),
            'post_type'		    => "tribe_events",
        );
        $save = DB::table( 'wp_posts' )->insert( $adds );
        $order_id = DB::getPdo()->lastInsertId();
        DB::table('wp_posts')
		->where('ID','=',$order_id)
		->update([
		    'post_parent'	=> $order_id,
		]);
        $event[] = array(
            'post_id'		    => $order_id,
            'start_date'		=> $request->start_date,
            'end_date' 		    => $request->end_date,
            'timezone'		    => $request->timezone,
            'start_date_utc'	=> $request->start_date,
            'end_date_utc' 		=> $request->end_date,
            'duration'		    => $request->duration,
        );
        $sav2 = DB::table( 'wp_tec_events' )->insert( $event );
        $event_id = DB::getPdo()->lastInsertId();
        $hash =  $this->generateRandomString(30);
        $accuranse[] = array(
            'event_id'		    => $event_id,
            'post_id'		    => $order_id,
            'start_date' 		=> $request->start_date,
            'start_date_utc'    => $request->start_date,
            'end_date' 		    => $request->end_date,
            'end_date_utc' 		=> $request->end_date,
            'duration'		    => $request->duration,
            'hash'		        => $hash,
        );
        DB::table( 'wp_tec_occurrences' )->insert( $accuranse );
        if ( $save ) {
            return response()->json( [ 'message' => 'Event Saved Successfully' ], 200 );
        } else {
            return response()->json( 'Oops! Something Went Wrong', 400 );
        }
    }

    public function eventlist( Request $request ) {
        $data = DB::table( 'wp_posts as w' )
        ->select( 'w.ID','w.post_date','w.post_content','w.post_title','w.post_status','w.post_name','wp.post_parent','wp.guid','start_date','end_date','timezone','start_date_utc','end_date_utc','duration' )
        ->join ('wp_posts as wp','w.ID', '=','wp.post_parent')
        ->join ('wp_tec_events as ev','w.ID', '=','ev.post_id')
        ->where('w.post_status','=',"publish")
        // ->where('wp.post_mime_type','=', 'image/jpeg')
        ->where('wp.post_type','=', 'attachment')
    	->orderBy('w.ID','DESC')
		->paginate(5);
          if ( isset( $data ) ) {
            return response()->json( [ 'data' => $data, 'message' => 'Event List' ], 200 );
        } else {
            return response()->json( [ 'data' => $emptyarray, 'message' => 'Event List' ], 200 );
        }
    }
    public function searchevent( Request $request ) {
        $validate = Validator::make($request->all(), [ 
	      'event_title'	=> 'required',
	    ]);
     	if ($validate->fails()) {
			return response()->json("Event Title Is Required", 400);
		}
        $data = DB::table( 'wp_posts as w' )
        ->select( 'w.ID','w.post_date','w.post_content','w.post_title','w.post_status','w.post_name','wp.post_parent','wp.guid','start_date','end_date','timezone','start_date_utc','end_date_utc','duration' )
        ->join ('wp_posts as wp','w.ID', '=','wp.post_parent')
        ->join ('wp_tec_events as ev','w.ID', '=','ev.post_id')
        ->where('w.post_status','=',"publish")
        // ->where('wp.post_mime_type','=', 'image/jpeg')
        ->where('wp.post_type','=', 'attachment')
        ->where('w.post_title','like','%'.$request->event_title.'%')
    	->orderBy('w.ID','DESC')
		->get();
          if ( isset( $data ) ) {
            return response()->json( [ 'data' => $data, 'message' => 'Event List' ], 200 );
        } else {
            return response()->json( [ 'data' => $emptyarray, 'message' => 'Event List' ], 200 );
        }
    }
    public function monthlyevents( Request $request ) {
        $validate = Validator::make($request->all(), [ 
	      'event_month'	=> 'required',
	    ]);
     	if ($validate->fails()) {
			return response()->json("Event Month Is Required", 400);
		}
        $data = DB::table( 'wp_posts as w' )
        ->select( 'w.ID','w.post_date','w.post_content','w.post_title','w.post_status','w.post_name','wp.post_parent','wp.guid','start_date','end_date','timezone','start_date_utc','end_date_utc','duration' )
        ->join ('wp_posts as wp','w.ID', '=','wp.post_parent')
        ->join ('wp_tec_events as ev','w.ID', '=','ev.post_id')
        ->where('w.post_status','=',"publish")
        // ->where('wp.post_mime_type','=', 'image/jpeg')
        ->where('wp.post_type','=', 'attachment')
        ->where('ev.start_date','like','%'.$request->event_month.'%')
    	->orderBy('w.ID','DESC')
		->get();
          if ( isset( $data ) ) {
            return response()->json( [ 'data' => $data, 'message' => 'Event List' ], 200 );
        } else {
            return response()->json( [ 'data' => $emptyarray, 'message' => 'Event List' ], 200 );
        }
    }
    public function dailyyevents( Request $request ) {
        $validate = Validator::make($request->all(), [ 
	      'event_date'	=> 'required',
	    ]);
     	if ($validate->fails()) {
			return response()->json("Event Date Is Required", 400);
		}
        $data = DB::table( 'wp_posts as w' )
        ->select( 'w.ID','w.post_date','w.post_content','w.post_title','w.post_status','w.post_name','wp.post_parent','wp.guid','start_date','end_date','timezone','start_date_utc','end_date_utc','duration' )
        ->join ('wp_posts as wp','w.ID', '=','wp.post_parent')
        ->join ('wp_tec_events as ev','w.ID', '=','ev.post_id')
        ->where('w.post_status','=',"publish")
        // ->where('wp.post_mime_type','=', 'image/jpeg')
        ->where('wp.post_type','=', 'attachment')
        ->where('ev.start_date','like','%'.$request->event_date.'%')
    	->orderBy('w.ID','DESC')
		->get();
          if ( isset( $data ) ) {
            return response()->json( [ 'data' => $data, 'message' => 'Event List' ], 200 );
        } else {
            return response()->json( [ 'data' => $emptyarray, 'message' => 'Event List' ], 200 );
        }
    }
    public function singleeventdetail( Request $request ) {
        $validate = Validator::make($request->all(), [ 
	      'ID'	=> 'required',
	    ]);
     	if ($validate->fails()) {
			return response()->json("Event ID Is Required", 400);
		}
        $data = DB::table( 'wp_posts as w' )
        ->select( 'w.ID','w.post_date','w.post_content','w.post_title','w.post_status','w.post_name','wp.post_parent','wp.guid','start_date','end_date','timezone','start_date_utc','end_date_utc','duration' )
        ->join ('wp_posts as wp','w.ID', '=','wp.post_parent')
        ->join ('wp_tec_events as ev','w.ID', '=','ev.post_id')
        ->where('w.post_status','=',"publish")
        // ->where('wp.post_mime_type','=', 'image/jpeg')
        ->where('wp.post_type','=', 'attachment')
        ->where('w.ID','=',$request->ID)
    	->first();
          if ( isset( $data ) ) {
            return response()->json( [ 'data' => $data, 'message' => 'Event Details' ], 200 );
        } else {
            return response()->json( [ 'data' => $emptyarray, 'message' => 'Event Details' ], 200 );
        }
    }
    public  function generateRandomString($length = 20){
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
	}
}