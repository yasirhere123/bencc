<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Validator;

class loginController extends Controller
 {
    public function signup( Request $request ) {
        $validate = Validator::make( $request->all(), [
            'email'         => 'required',
            'user_name'     => 'required',
            'password'      => 'required|min:6',
        ] );
        if ( $validate->fails() ) {
            return response()->json( $validate->errors(), 400 );
        }
        $emailExists = User::where( 'email', $request->email )->first();
        if ( $emailExists ) {
            return response()->json( [ 'error' => 'Email already exists' ], 400 );
        }
        $data = [
            'user_name'     => $request->user_name,
            'email'         => $request->email,
            'password'      => Hash::make( $request->password ),
            'user_date'     => date( 'Y-m-d' ),
            'created_at'    => date( 'Y-m-d h:i:s' ),
        ];
        $saveData = User::create( $data );
        if ( $saveData ) {
            return response()->json( [ 'success'=> 'Signup successfully' ], 200 );
        } else {
            return response()->json( [ 'error' => 'Oops! something went wrong' ], 400 );
        }
    }

    public function login( Request $request ) {
        $credentials = $request->only( 'email', 'password' );
        $validate = Validator::make( $credentials, [
            'email'     => 'required',
            'password'  => 'required'
        ] );
        if ( $validate->fails() ) {
            return response()->json( $validate->errors(), 400 );
        }
        $email = User::where( 'email', $request->email )->first();
        if ( $email ) {
            $checkPass = Hash::check( $request->password, $email->password );
            if ( $checkPass ) {
                try {
                    $token = JWTAuth::attempt( $credentials );
                    if ( !$token ) {
                        return response()->json( [ 'error' => 'Invalid Login credentials' ], 400 );
                    } else {
                        return response()->json( [ 'token' => $token ], 200 );
                    }

                } catch( JWTException $e ) {
                    return response()->json( [ 'error'=>$e->getMessage() ], 400 );
                }
            } else {
                return response()->json( [ 'error' => 'wrong password' ],  400 );
            }
        } else {
            return response()-> json( [ 'error' => 'email does not exists' ], 400 );
        }
        return response()->json( [ 'token' => $token ], 200 );
    }

    public function logout( Request $request ) {
        $validate = Validator::make( $request->only( 'token' ), [
            'token' => 'required'
        ] );
        if ( $validate->fails() ) {
            return response()-> json( $validate->errors(), 400 );
        }
        try {
            JWTAuth::invalidate( $request-> token );
            return response() -> json( [ 'success' => 'logged out successfully' ], 200 );
        } catch( JWTException $ex ) {
            return response()-> json( $ex->getMessage(), 400 );
        }
    }

    public function getUser( Request $request ) {
        $user = JWTAuth::authenticate( $request->token );
        return response()-> json( [ 'user' => $user ], 200 );
    }
}